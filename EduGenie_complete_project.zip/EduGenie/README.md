# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a FastAPI + HTML/CSS learning assistant based on the supplied project documentation.

## Features

- Question & Answer: `/qa`
- Concept explanation: `/explain`
- MCQ quiz generation: `/quiz`
- Text summarization: `/summarize`
- Personalized learning path: `/learn/recommendations`
- Browser frontend served by FastAPI
- Gemini integration using Google's current `google-genai` SDK
- Optional local LaMini-Flan-T5 concept explainer

The supplied documentation describes Gemini 1.5 Pro and LaMini-Flan-T5-783M. Gemini model availability changes over time, so the model is configurable through `GEMINI_MODEL`. The default in this implementation is a current Gemini model.

## Windows setup

Open VS Code in this folder and open **Terminal > New Terminal**.

### 1. Create a virtual environment

```powershell
py -3.10 -m venv .venv
```

### 2. Activate it

PowerShell:

```powershell
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks scripts:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

Then activate again.

Command Prompt:

```cmd
.venv\Scripts\activate
```

### 3. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Configure Gemini

Copy `.env.example` to `.env`:

```powershell
Copy-Item .env.example .env
```

Open `.env` and replace:

```text
GEMINI_API_KEY=your_google_ai_studio_api_key_here
```

with your real key.

Do not commit `.env` to Git.

### 5. Start the server

```powershell
python -m uvicorn main:app --reload
```

Open:

http://127.0.0.1:8000

FastAPI docs:

http://127.0.0.1:8000/docs

Health check:

http://127.0.0.1:8000/health

## Testing

Run:

```powershell
pytest -q
```

The included tests do not call Gemini; they verify that the app and health endpoint start correctly.

For an end-to-end AI test, open the web page and try:

- Q&A: `Which is the largest ocean?`
- Explain: `Pythagorean theorem`
- Quiz: `Photosynthesis converts light energy into chemical energy...`
- Summary: paste an educational paragraph
- Learning Path: `SQL`

## Optional local LaMini model

The original documentation assigns concept explanation to `MBZUAI/LaMini-Flan-T5-783M`.

To use it:

```text
USE_LOCAL_EXPLAINER=true
```

The first explanation request downloads the model from Hugging Face and can take time and disk space. If it fails to load, EduGenie automatically falls back to Gemini so the application remains usable.

## Administrative privileges

You normally **do not need to run VS Code as Administrator**. Use a normal terminal whenever possible.

If your Windows Python installation or corporate machine requires elevated permissions to install software, open PowerShell/VS Code as Administrator only for that installation step. The application itself can run as a normal user.

## Project structure

```text
EduGenie/
├── main.py
├── config.py
├── ai_client.py
├── schemas.py
├── qna.py
├── explanation_module.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   └── style.css
└── tests/
    └── test_api.py
```
