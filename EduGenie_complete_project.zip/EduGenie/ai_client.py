from functools import lru_cache
from google import genai
from google.genai import types

from config import GEMINI_API_KEY, GEMINI_MODEL, MAX_INPUT_CHARS


class GeminiService:
    def __init__(self):
        if not GEMINI_API_KEY:
            raise RuntimeError(
                "GEMINI_API_KEY is missing. Add it to the .env file before using AI features."
            )
        self.client = genai.Client(api_key=GEMINI_API_KEY)
        self.model = GEMINI_MODEL

    def generate(
        self,
        prompt: str,
        system_instruction: str = "You are EduGenie, a helpful educational assistant.",
        temperature: float = 0.4,
        max_output_tokens: int = 1200,
        response_mime_type: str | None = None,
    ) -> str:
        prompt = prompt[:MAX_INPUT_CHARS]
        config_kwargs = {
            "system_instruction": system_instruction,
            "temperature": temperature,
            "max_output_tokens": max_output_tokens,
        }
        if response_mime_type:
            config_kwargs["response_mime_type"] = response_mime_type

        response = self.client.models.generate_content(
            model=self.model,
            contents=prompt,
            config=types.GenerateContentConfig(**config_kwargs),
        )
        text = getattr(response, "text", None)
        if not text:
            raise RuntimeError("Gemini returned an empty response.")
        return text.strip()


@lru_cache(maxsize=1)
def get_gemini_service() -> GeminiService:
    return GeminiService()
