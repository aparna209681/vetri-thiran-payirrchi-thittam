from functools import lru_cache

from config import LOCAL_EXPLAINER_MODEL, USE_LOCAL_EXPLAINER
from ai_client import get_gemini_service


@lru_cache(maxsize=1)
def _load_local_pipeline():
    from transformers import pipeline
    return pipeline(
        "text2text-generation",
        model=LOCAL_EXPLAINER_MODEL,
        device=-1,
    )


def _local_explain(topic: str) -> str:
    generator = _load_local_pipeline()
    prompt = (
        "Explain this educational topic for a beginner in simple language, "
        "using a short example and avoiding unnecessary jargon: " + topic
    )
    result = generator(prompt, max_new_tokens=220, do_sample=False)
    return result[0]["generated_text"].strip()


def explain_concept(topic: str) -> str:
    if USE_LOCAL_EXPLAINER:
        try:
            return _local_explain(topic)
        except Exception:
            # If the optional local model cannot load, keep the application usable.
            pass

    prompt = f"""
Explain the following concept to a beginner:
{topic}

Use:
- a one-sentence definition
- a simple explanation
- one everyday analogy or example
- 2-4 key points
- a short "check your understanding" question

Keep it concise and educational.
"""
    return get_gemini_service().generate(
        prompt,
        system_instruction="You are a patient teacher who simplifies difficult concepts without losing correctness.",
        temperature=0.35,
        max_output_tokens=1000,
    )
