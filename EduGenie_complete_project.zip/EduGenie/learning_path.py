from ai_client import get_gemini_service


def get_learning_recommendations(topic: str, level: str = "beginner") -> str:
    prompt = f"""
Create a personalized learning path for the topic "{topic}".
Learner level: {level}

Organize it from foundational to advanced learning.

Include:
- prerequisites
- stages/topics in order
- suggested time for each stage
- a practical activity or project for each stage
- useful resource types (documentation, videos, articles, books)
- a short final project
- advice for checking progress

Do not fabricate specific URLs. If naming a resource, prefer well-known official
documentation or describe the resource type rather than inventing a link.
"""
    return get_gemini_service().generate(
        prompt,
        system_instruction="You are a personalized learning-path designer and academic mentor.",
        temperature=0.45,
        max_output_tokens=1800,
    )
