from ai_client import get_gemini_service


def answer_question(question: str) -> str:
    prompt = f"""
Answer the student's question accurately and clearly.

Student question:
{question}

Requirements:
- Give the direct answer first.
- Explain important reasoning or context briefly.
- Use simple language suitable for a learner.
- If the question is ambiguous, state the assumption you made.
- Do not invent sources or facts.
"""
    return get_gemini_service().generate(
        prompt,
        system_instruction="You are an accurate, concise academic question-answering tutor.",
        temperature=0.25,
        max_output_tokens=1000,
    )
