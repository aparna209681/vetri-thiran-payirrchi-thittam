import json
import re
from typing import Any

from ai_client import get_gemini_service


def clean_json_block(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\s*```$", "", text)
    return text.strip()


def _normalize_question(item: dict[str, Any]) -> dict[str, Any]:
    question = str(item.get("question", "")).strip()
    options = item.get("options", [])
    answer = item.get("correct_answer", item.get("answer", ""))

    if not isinstance(options, list):
        options = []

    options = [str(x).strip() for x in options if str(x).strip()]
    return {
        "question": question,
        "options": options[:4],
        "correct_answer": str(answer).strip(),
        "explanation": str(item.get("explanation", "")).strip(),
    }


def generate_quiz(text: str, count: int = 3) -> list[dict[str, Any]]:
    prompt = f"""
Create exactly {count} multiple-choice questions from this educational material.

Material:
{text}

Return ONLY valid JSON matching this structure:
[
  {{
    "question": "question text",
    "options": ["option A", "option B", "option C", "option D"],
    "correct_answer": "the exact correct option text",
    "explanation": "brief explanation"
  }}
]

Rules:
- Exactly four options per question.
- Exactly one correct answer.
- Questions must be answerable from the supplied material.
- Distractors should be plausible.
- No markdown fences.
"""
    raw = get_gemini_service().generate(
        prompt,
        system_instruction="You create rigorous educational MCQs and must return valid JSON.",
        temperature=0.35,
        max_output_tokens=1800,
        response_mime_type="application/json",
    )
    data = json.loads(clean_json_block(raw))
    if not isinstance(data, list):
        raise ValueError("Quiz response was not a JSON list.")

    normalized = [_normalize_question(x) for x in data[:count]]
    if len(normalized) != count or any(
        not q["question"] or len(q["options"]) != 4 or not q["correct_answer"]
        for q in normalized
    ):
        raise ValueError("Gemini returned an invalid quiz structure.")
    return normalized
