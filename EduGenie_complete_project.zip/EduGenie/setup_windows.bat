@echo off
py -3.10 -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Setup complete. Edit .env and add GEMINI_API_KEY.
echo Then run run_windows.bat
pause
