from ai_client import get_gemini_service


def summarize_text(text: str) -> str:
    prompt = f"""
Summarize the following educational text for quick revision.

Text:
{text}

Return:
1. A short paragraph summary.
2. 3-7 key points as bullets.
3. Important terms or formulas, if present.
Keep the original meaning and do not add unsupported facts.
"""
    return get_gemini_service().generate(
        prompt,
        system_instruction="You are an educational summarization specialist.",
        temperature=0.2,
        max_output_tokens=1200,
    )
